export const environment = {
  production: true,
  HOST: 'http://10.154.80.177',
  PRO_TOKEN: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiZ2VzdG9yX2ludGVybm8ifQ.pjwTkG0CrF-vXIKT4hME-lRdFlWv8-wcnr3Pr_QdHo4',
  APP_JSON: 'application/json'
};
