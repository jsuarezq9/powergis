import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ComponentsInteractionService } from '../../services/interactions.service';

import VectorSource from 'ol/source/Vector';
import GeoJSON from 'ol/format/GeoJSON.js';
import { bbox as bboxStrategy } from 'ol/loadingstrategy.js';


@Component({
  selector: 'app-legend',
  templateUrl: './legend.component.html',
  styleUrls: ['./legend.component.css']
})
export class LegendComponent implements OnInit {

  @Output() legendSelected = new EventEmitter();
  // Leyenda
  layers = [];

  constructor(private interaction: ComponentsInteractionService) { }

  ngOnInit() {
    // Cada vez que se edite una capa en módulo 1
    this.interaction.mapInteraction.subscribe(( layer: any ) => {
      // Agrego al arreglo si show=true
      if (layer.show) {
        this.layers.push(layer);
      } else {
        const index = this.layers.indexOf(layer, 0);
        if (index > -1) {
          this.layers.splice(index, 1);
        }
      }

      this.getLegend();
      // Consulto el tipo de geometría de la nueva capa
      console.log('LEGENDCOMP', this.layers);
    });

    this.getLegend();
  }

  select(event) {
    this.legendSelected.emit(event);
  }

  getLegend() {
    if (this.layers.length === 0) {
      // ESCONDER LEYENDA
      document.getElementById('buttonCollapseLegendDiv').style.display = 'none';
    } else {
      // MOSTRAR LEYENDA
      document.getElementById('buttonCollapseLegendDiv').style.display = 'flex';
    }
  }

  requestLayerWFS(type: string, name: string, count ?: any) {
    console.log(count);

    const vectorSource = new VectorSource({
      format: new GeoJSON(),
      loader(extent, resolution, projection) {
        const proj = projection.getCode();
        let url: string;
        // tslint:disable-next-line: max-line-length
        url = `http://elaacgresf00.enelint.global:8080/geoserver/${type}/wfs?service=WFS&version=2.0.0&request=GetFeature&typename=${type}:${name}&${count}outputFormat=application/json&srsname=${proj}`;
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        const onError = () => {
          vectorSource.removeLoadedExtent(extent);
          alert(`Error while requesting (${name} - ${type})`);
        };
        xhr.onerror = onError;
        xhr.onload = () => {

          if (xhr.status === 200) {
            vectorSource.addFeatures(vectorSource.getFormat().readFeatures(xhr.responseText));
          } else {
            onError();
          }
        };
        xhr.send();
      },
      strategy: bboxStrategy
    });
    return vectorSource;
  }


}
