import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modulehidro',
  templateUrl: './modulehidro.component.html',
  styleUrls: ['./modulehidro.component.css']
})
export class ModulehidroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
